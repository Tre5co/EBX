"""PROPOSAL: Pydantic v2 request/response schemas for the v2 (mission-centric)
API. Parallel to schemas.py; nothing imports it until cutover.

Naming mirrors models_v2: ben / tiv / org. `*Create` = request bodies,
`*Read` = responses (ConfigDict(from_attributes=True) so they read straight off
ORM objects). Valence and post-vote values are helpful | neutral | harmful.
"""
from __future__ import annotations

import json as _json
from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

Valence = Literal["helpful", "neutral", "harmful"]


# ---------------------------------------------------------------------------
# Cause
# ---------------------------------------------------------------------------
class CauseBase(BaseModel):
    name: str
    color: str
    emoji: Optional[str] = None
    description: Optional[str] = None


class CauseCreate(CauseBase):
    id: str
    index: int


class CauseRead(CauseBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    # §5 (2026-08-06): a SUGGESTED cause holds no window yet, so index is None
    # until it wins one.
    index: Optional[int] = None
    status: str = "active"
    proposed_by_id: Optional[int] = None


class CauseSuggest(BaseModel):
    """A benefactor proposing a cause — name plus the colour they picked off
    the wheel, since a cause is recognised by its colour everywhere."""
    name: str
    color: str
    description: Optional[str] = None
    emoji: Optional[str] = None


class CauseVoteCast(BaseModel):
    # §1 (2026-08-21): 1..13 — the six confirmed windows and the seven open ones
    # behind them. `crud.cast_cause_vote` is the authority on which accept a vote.
    slot: int
    cause_id: str


# ---------------------------------------------------------------------------
# Mission (the spine)
# ---------------------------------------------------------------------------
class MissionBase(BaseModel):
    cause_id: str
    cycle_num: int
    current_phase: str = "pre"  # pre | initiative | budget | credit | resolution


class MissionCreate(MissionBase):
    id: str


class MissionRead(MissionBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    started_at: Optional[datetime] = None
    winning_tiv_id: Optional[str] = None
    winning_org_id: Optional[str] = None
    budget: int = 0
    spent: int = 0
    credit_value: float = 1.0
    guaranteed_pool_rate: Optional[float] = None  # NULL = unclaimed default
    projected_end_at: Optional[datetime] = None   # projected mission length (§1d)
    updated_at: datetime


# ---------------------------------------------------------------------------
# Initiative (tiv)
# ---------------------------------------------------------------------------
class InitiativeBase(BaseModel):
    title: str
    description: Optional[str] = None
    emoji: Optional[str] = None
    cause_id: str
    status: str = "suggested"  # suggested | active | resolved (elected tiv -> active; -> resolved at distribution)


class InitiativeCreate(InitiativeBase):
    # build-seq §3 (2026-09-16): a title is a short name; the case is the
    # description. Enforced on creation only, so older long titles still read.
    title: str = Field(min_length=3, max_length=120)
    id: str
    mission_id: Optional[str] = None
    proposer_ben_id: Optional[int] = None
    proposer_org_id: Optional[str] = None


class InitiativeRead(InitiativeBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    mission_id: Optional[str] = None
    proposer_ben_id: Optional[int] = None
    proposer_org_id: Optional[str] = None
    proposed_at: datetime
    rating_avg: float = 0.0
    rating_count: int = 0
    logo_url: Optional[str] = None
    approved: bool = False
    ebx_committed: float = 0   # aggregate committed EBX across all phase-1 votes


# ---------------------------------------------------------------------------
# Organization
# ---------------------------------------------------------------------------
class OrganizationBase(BaseModel):
    name: str
    description: Optional[str] = None
    website_link: Optional[str] = None
    founded_year: Optional[int] = None
    verified: bool = False


class OrganizationCreate(OrganizationBase):
    id: str
    founding_member_id: Optional[int] = None


class OrganizationRead(OrganizationBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    founding_member_id: Optional[int] = None
    joined_at: Optional[datetime] = None
    score: float = 0.0
    logo_url: Optional[str] = None


# ---------------------------------------------------------------------------
# Benefactor account & auth (role = the employee category)
# ---------------------------------------------------------------------------
class BenefactorCreate(BaseModel):
    email: EmailStr
    handle: str = Field(min_length=2, max_length=40)
    password: str = Field(min_length=8, max_length=72)


class BenefactorRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: EmailStr
    handle: str
    is_active: bool
    role: str = "benefactor"  # benefactor | employee | admin
    vvv: bool = False
    is_test: bool = False            # the bot signature (build-seq §2)
    created_at: datetime
    watched_tiv_ids: list[str] = Field(default_factory=list)

    @field_validator("watched_tiv_ids", mode="before")
    @classmethod
    def _parse_watched(cls, v: object) -> list[str]:
        if v is None:
            return []
        if isinstance(v, list):
            return [str(x) for x in v]
        try:
            parsed = _json.loads(v)  # type: ignore[arg-type]
            if isinstance(parsed, list):
                return [str(x) for x in parsed]
        except (TypeError, ValueError):
            pass
        return []


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: Optional[str] = None  # ben id as string
    exp: Optional[int] = None


# ---------------------------------------------------------------------------
# Membership
# ---------------------------------------------------------------------------
OrgRole = Literal["community", "rep", "executive", "beneficiary"]


class MembershipCreate(BaseModel):
    """Invite/add a member to an org. Identify the ben by id OR handle/email."""
    ben_id: Optional[int] = None
    handle: Optional[str] = None
    email: Optional[str] = None
    role: OrgRole = "community"


class MembershipRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    ben_id: int
    org_id: str
    role: str  # community | rep | executive | beneficiary
    joined_at: datetime


class MembershipDetail(MembershipRead):
    """Membership row enriched with the member's handle (org members list)."""
    handle: Optional[str] = None


# ---------------------------------------------------------------------------
# Mission candidacy (org's bid to run a mission)
# ---------------------------------------------------------------------------
class MissionCandidacyCreate(BaseModel):
    mission_id: str
    org_id: str
    mission_statement: Optional[str] = None


class MissionCandidacyRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    mission_id: str
    org_id: str
    mission_statement: Optional[str] = None
    status: str = "pending"  # pending | approved | withdrawn | won | lost
    submitted_by_id: Optional[int] = None
    approved_by_id: Optional[int] = None
    p2_vote_tally: int = 0
    created_at: datetime


# ---------------------------------------------------------------------------
# Org self-registration / nomination (public application) — Build Phase 2 (A)
# ---------------------------------------------------------------------------
class OrganizationRegister(BaseModel):
    """Public org application. kind='registration' = a real member registers
    (founding executive membership); kind='nomination' = a benefactor puts an
    org forward (no membership created). Pass org_id to use an existing org
    (picked from a duplicate match) instead of creating a new one; pass
    force=True to create despite fuzzy matches."""
    name: str = Field(min_length=2, max_length=120)
    description: Optional[str] = None
    website_link: Optional[str] = None
    founded_year: Optional[int] = None
    logo_url: Optional[str] = None
    kind: Literal["registration", "nomination"] = "registration"
    org_id: Optional[str] = None          # use existing org instead of creating
    mission_id: Optional[str] = None      # also enter this mission's org race
    mission_statement: Optional[str] = None
    member_name: Optional[str] = None     # registration attestation details
    member_position: Optional[str] = None
    force: bool = False


class OrgMatch(BaseModel):
    org_id: str
    name: str
    score: float                          # 0..1 fuzzy similarity


class OrgRegisterResult(BaseModel):
    created: bool                         # False = duplicates found, nothing written
    org: Optional[OrganizationRead] = None
    membership: Optional[MembershipRead] = None
    candidacy: Optional[MissionCandidacyRead] = None
    matches: list[OrgMatch] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Org claim (THE gate) — click-through legal acceptance — Build Phase 2 (D)
# ---------------------------------------------------------------------------
class OrgClaimCreate(BaseModel):
    org_id: str
    kind: Literal["claim", "register"] = "claim"
    attestation_version: Optional[str] = None   # defaults to settings.attestation_version
    member_name: Optional[str] = None
    member_position: Optional[str] = None


class OrgClaimRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    mission_id: str
    org_id: str
    ben_id: int
    kind: str
    attestation_version: str
    member_name: Optional[str] = None
    member_position: Optional[str] = None
    accepted_at: datetime


# ---------------------------------------------------------------------------
# Mission steps (release-phase structure, §1d) — each step carries a
# guaranteed and a potential pool (no maximums); resolving one is a RESOLUTION.
# ---------------------------------------------------------------------------
class MissionStepCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    description: Optional[str] = None
    order_num: int = 0
    guaranteed_ebx: int = Field(default=0, ge=0)
    potential_ebx: int = Field(default=0, ge=0)   # open-ended, no maximum
    starts_at: Optional[datetime] = None
    due_at: Optional[datetime] = None


class MissionStepRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    mission_id: str
    title: str
    description: Optional[str] = None
    order_num: int = 0
    guaranteed_ebx: int = 0
    potential_ebx: int = 0
    starts_at: Optional[datetime] = None
    due_at: Optional[datetime] = None
    status: str = "planned"   # planned | active | resolved
    resolved_at: Optional[datetime] = None
    created_by_id: Optional[int] = None
    created_at: datetime


class ProjectedEndSet(BaseModel):
    projected_end_at: datetime


# ---------------------------------------------------------------------------
# VoteP1 (tiv election — split shares; carries committed EBX)
# ---------------------------------------------------------------------------
class VoteP1Create(BaseModel):
    tiv_id: str
    share: float = Field(default=1.0, ge=0.1, le=1.0)
    ebx_committed: int = Field(default=0, ge=0)
    valence: Valence = "helpful"


class VoteP1Shares(BaseModel):
    """Full shares map a ben PUTs for a mission's phase-1 election.

    initiative shares must each be >= 0.1 and sum to <= 1.0 (validated server-side).
    """
    mission_id: str
    shares: dict[str, float]
    ebx: int = 0   # total EBX committed, split across the slate by share (replace)


class VoteP1Read(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    ben_id: int
    mission_id: str
    tiv_id: str
    share: float = 1.0
    ebx_committed: float = 0   # holdings x share (continuous — not rounded)
    # §1 (2026-08-28): the finalized model's field, so a client reads the same
    # integer the server does instead of re-deriving it from the legacy float.
    # `wallet.p1_stake_ct_of` is the fallback for rows written before it.
    stake_ct: int = 0
    valence: Valence = "helpful"
    committed: bool = False
    created_at: datetime


# ---------------------------------------------------------------------------
# VoteP2 (org election — 1 org, buy extra votes; harmful = block)
# ---------------------------------------------------------------------------
class VoteP2Create(BaseModel):
    org_id: str
    votes: int = Field(default=1, ge=1)
    ebx_spent: int = Field(default=0, ge=0)
    valence: Valence = "helpful"


class VoteP2Read(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    ben_id: int
    mission_id: str
    # OPTIONAL since 2026-08-19. A stake can exist with no philanthropy named:
    # the initiative election moves every backer's remainder into the winning
    # initiative's organization election automatically, and nobody chose an org
    # for them. A required `str` here made `GET /benefactors/me/p2-votes` return
    # 500 the moment one of those rows existed — the response model, not the
    # database, was the last thing still insisting a stake must have a vote.
    org_id: Optional[str] = None
    votes: int = 1
    ebx_spent: int = 0
    valence: Valence = "helpful"
    committed: bool = False
    created_at: datetime
    # The explicit stake and its own 15-week clock (token_model.py).
    stake_ct: int = 0
    origin_mission_id: Optional[str] = None
    born_week: Optional[int] = None


# ---------------------------------------------------------------------------
# Pool (derived money rollup)
# ---------------------------------------------------------------------------
class PoolRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    mission_id: str
    phase1_total_ebx: int = 0
    phase2_total_ebx: int = 0
    pool_from_winners: int = 0
    pool_from_losers: int = 0
    total_locked: int = 0
    updated_at: datetime


# ---------------------------------------------------------------------------
# CreditCoin
# ---------------------------------------------------------------------------
class CreditCoinRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    owner_id: int
    mission_id: str
    amount_ebx: int
    value: float = 1.0
    issued_at: datetime
    redeemed: bool = False


# ---------------------------------------------------------------------------
# Posts & post votes
# ---------------------------------------------------------------------------
class PostBase(BaseModel):
    # Supercategory. Benefactor: budgeting|mission_support|review · org/staff:
    # org_update|mission_update|testimonial|editorial|headline|resolution.
    category: str = "editorial"
    # Subcategory (the leaf a ben posts under); null for org/staff cats.
    # See app/post_config.py for the (category → type) taxonomy.
    type: Optional[str] = None
    title: Optional[str] = None
    body: str
    author_type: str = "earthbux"  # ben | org | earthbux
    mission_id: Optional[str] = None
    tiv_id: Optional[str] = None
    cause_id: Optional[str] = None
    org_id: Optional[str] = None     # target org (evaluation / org-scoped posts)
    stance: Optional[str] = None     # case: for|against · evaluation: positive|negative
    parent_id: Optional[str] = None  # set for a comment (reply to another post)
    image_url: Optional[str] = None  # attached image (data URL or path)
    # §2a: budgeting posts (service|supply|support) must carry both estimates.
    est_setup_days: Optional[float] = None  # how long to stand it up
    est_cost_usd: Optional[float] = None    # what it costs
    # §1 (2026-08-12): the costed list a budgeting suggestion is made of —
    # service {job, hourly_rate, days_needed} · supply {item, supplier, cost} ·
    # support {item}. The estimates above are derived from it when omitted.
    line_items: Optional[list[dict]] = None
    # P3 (2026-09-29): what the post is about, stated once — cause · initiative
    # · organization · mission · post · budget · none — and its tags (a general
    # post's subtype, entity tags like "tiv:<id>"). post_config.py has the rules.
    target_kind: Optional[str] = None
    target_id: Optional[str] = None
    tags: Optional[list[str]] = None


class PostCreate(PostBase):
    id: str
    ben_author_id: Optional[int] = None
    org_author_id: Optional[str] = None
    # What the post cites: {kind: post, post_id, version?} · {kind: mission,
    # mission_id} · {kind: link, url, label?}. An Analysis's Backgrounds and
    # Investigations go here (12 + 12, the two leading ones attached for you).
    references: Optional[list[dict]] = None


class PostRead(PostBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    ben_author_id: Optional[int] = None
    org_author_id: Optional[str] = None
    helpful_count: int = 0
    neutral_count: int = 0
    harmful_count: int = 0
    created_at: datetime
    # Post-support layer: green | orange | red. Only org-tagged types (case,
    # investigation, evaluation) are meaningfully rated — see post_config.
    flag: str = "green"
    flag_reason: Optional[str] = None
    # P3 — how every page displays a post (`posting.serialize`).
    version: int = 1
    latest_version: int = 1
    version_shown: int = 1
    updated_at: Optional[datetime] = None
    target_label: Optional[str] = None
    mission_label: Optional[str] = None
    reply_count: int = 0
    vote_name: Optional[str] = None
    author_name: Optional[str] = None
    # Read inside a mission: {mission_id, via, pinned_version} — the counts
    # above are that mission's, and the body is the version it keeps.
    in_mission: Optional[dict] = None
    # Posting pass (2026-10-01): did the author vote in the initiative election
    # of the mission the post belongs to? None when it belongs to none.
    author_in_me: Optional[bool] = None
    # Posting edits (2026-10-02): who it comes from — earthbux · charity ·
    # individual (Home's toggles) — and the targeted mission's next decision,
    # {label, date}, for the card's top bar.
    source: Optional[str] = None
    next_decision: Optional[dict] = None


class PostDetail(PostRead):
    """The full view: references (and whether each changed since it was cited),
    who cites it, every version, every mission it belongs to."""
    references: list[dict] = []
    cited_by: int = 0
    versions: list[dict] = []
    missions: list[dict] = []


class PostUpdate(BaseModel):
    """An author's edit to their own post. Every edit is a new version (D21);
    category, type, target and parent never move."""
    title: Optional[str] = None
    body: Optional[str] = None
    stance: Optional[str] = None
    line_items: Optional[list[dict]] = None
    est_setup_days: Optional[float] = None
    est_cost_usd: Optional[float] = None
    tags: Optional[list[str]] = None
    references: Optional[list[dict]] = None


class PostPull(BaseModel):
    """D21: bring your post from an earlier mission into this one."""
    mission_id: str


class PostFlagUpdate(BaseModel):
    """Staff override on the post-support layer (mission annulus)."""
    flag: str
    reason: Optional[str] = None


class PostVoteCreate(BaseModel):
    value: Valence
    # The mission the vote is cast in (D21: votes count per mission). Omitted,
    # it is the post's current mission.
    mission_id: Optional[str] = None


class PostVoteRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    post_id: str
    ben_id: int
    value: Valence
    created_at: datetime


# ---------------------------------------------------------------------------
# Query (employee-only data tool)
# ---------------------------------------------------------------------------
class QueryCreate(BaseModel):
    name: str
    description: Optional[str] = None
    entity: Optional[str] = None
    filters: Optional[str] = None  # JSON string
    sort: Optional[str] = None
    sql: Optional[str] = None
    shared: bool = False


class QueryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    description: Optional[str] = None
    entity: Optional[str] = None
    filters: Optional[str] = None
    sort: Optional[str] = None
    sql: Optional[str] = None
    created_by_id: Optional[int] = None
    shared: bool = False
    created_at: datetime
    last_run_at: Optional[datetime] = None


# ---------------------------------------------------------------------------
# Transaction (the ledger — read-only out of the API)
# ---------------------------------------------------------------------------
class TransactionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    type: str  # vote | transfer
    ben_id: Optional[int] = None
    mission_id: Optional[str] = None
    phase: Optional[str] = None
    action: Optional[str] = None
    target: Optional[str] = None
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    bucket: Optional[str] = None  # pool|org|earthbux|evaluation|credit|refund
    counterparty_org_id: Optional[str] = None
    amount_ebx: int = 0
    note: Optional[str] = None
    created_at: datetime
