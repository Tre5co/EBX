"""PROPOSAL: mission-centric ORM rewrite (v2). NOT wired into the app.

Nothing imports this file, so it cannot affect the running API or Alembic until
you promote it. Spine = `Mission`; everything else hangs off it.

Naming: short forms ben / tiv / org are used for attributes, columns, FKs and
relationships (all length 3). Class names stay descriptive (Initiative,
BenefactorAccount, Organization) so e.g. `tiv_id = ForeignKey("initiatives.id")`.

v2 changes vs models.py
-----------------------
* Mission is the SPINE (one cause+cycle slot, holds phase + winner pointers).
* Voting split into VoteP1 (tiv election) and VoteP2 (org election).
* Contribution merged onto VoteP1 (ebx_committed = live value).
* Transaction is the single append-only ledger (replaces VoteEvent): it records
  both vote mutations and EBX bucket movements (pool/org/earthbux/...), keeping
  the vote/mission/ben classes lean.
* `valence` (helpful|neutral|harmful) added to VoteP1/VoteP2 as the hook for the
  upcoming voting redesign (negative/against votes, org blocking). The WEIGHT
  math lives in crud, not here.
* organization_causes dropped — an org's causes derive through its candidacies
  -> missions -> cause.
* MissionCandidacy = an org's bid to run a mission (grants build access).
* Earthbux employees via BenefactorAccount.role; Query = staff-only data tool.
* PostVote values helpful|neutral|harmful. Initiative.rating_* is the aggregated
  average of its VoteP1 valence (recomputed in crud).
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


# ===========================================================================
# Cause — the 7 permanent rotation slots.
# (No more organization_causes link table: an org's causes are derived through
#  its mission candidacies, so the m2m `secondary` table is gone.)
# ===========================================================================
class Cause(Base):
    __tablename__ = "causes"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    # Rotation order 0..6 for a cause that currently HOLDS a window; NULL for a
    # suggested cause that is still campaigning for one (§5, 2026-08-06).
    index: Mapped[Optional[int]] = mapped_column(Integer, unique=True, nullable=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    color: Mapped[str] = mapped_column(String, nullable=False)
    emoji: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # 'active'    — holds one of the seven windows
    # 'suggested' — proposed by a benefactor, campaigning to replace one
    # 'retired'   — was replaced; kept so old missions still resolve their cause
    status: Mapped[str] = mapped_column(String, default="active", nullable=False)
    proposed_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    missions: Mapped[list["Mission"]] = relationship(back_populates="cause")
    votes: Mapped[list["CauseVote"]] = relationship(
        back_populates="cause", cascade="all, delete-orphan"
    )


# ===========================================================================
# CauseVote — §5 (2026-08-06). One benefactor's vote, for one WEEK, on which
# cause should hold an upcoming window.
#
# The contest runs SEVEN weeks but is advertised as six: week 1 is an
# aggregation of the six weeks *before* the contest opened, so a challenger
# that has quietly been winning already arrives with a head start rather than
# starting from nothing. A challenger takes a week by clearing **>50%** of
# that week's votes; taking all seven replaces the cause holding the window.
# ===========================================================================
class CauseVote(Base):
    __tablename__ = "cause_votes"
    __table_args__ = (
        UniqueConstraint("ben_id", "slot", "week_start", name="uq_cause_vote_ben_slot_week"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False)
    # Which upcoming window is being contested: 1 = the next one to open, …, 7.
    slot: Mapped[int] = mapped_column(Integer, nullable=False)
    cause_id: Mapped[str] = mapped_column(ForeignKey("causes.id"), nullable=False)
    # Monday (UTC) of the week this vote counts in — the unit the majority is
    # measured over.
    week_start: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ben: Mapped["BenefactorAccount"] = relationship()
    cause: Mapped["Cause"] = relationship(back_populates="votes")


# ===========================================================================
# Mission — THE SPINE. One (cause, cycle_num) slot, created at cycle start.
# Holds phase state + the singular WINNER pointers; candidates are on the
# back-ref collections (tivs, candidacies).
# ===========================================================================
class Mission(Base):
    __tablename__ = "missions"
    __table_args__ = (
        UniqueConstraint("cause_id", "cycle_num", name="uq_mission_cause_cycle"),
    )

    id: Mapped[str] = mapped_column(String, primary_key=True)
    cause_id: Mapped[str] = mapped_column(ForeignKey("causes.id"), nullable=False)
    cycle_num: Mapped[int] = mapped_column(Integer, nullable=False)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # 'pre' | 'initiative' | 'budget' | 'credit' | 'resolution'
    current_phase: Mapped[str] = mapped_column(String, default="pre", nullable=False)

    winning_tiv_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("initiatives.id"), nullable=True
    )
    winning_org_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("organizations.id"), nullable=True
    )

    budget: Mapped[int] = mapped_column(Integer, default=0)
    spent: Mapped[int] = mapped_column(Integer, default=0)
    credit_value: Mapped[float] = mapped_column(Float, default=1.0)
    # Guaranteed-to-pool rate. NULL = unclaimed default (settings.pool_rate_unclaimed);
    # set to the claimed rate when a representative claims the mission (org_claims).
    guaranteed_pool_rate: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    # Projected MISSION LENGTH end date (release-phase structure, §1d). One
    # strategy: end right before the cause's next phase 1 so the org can bid
    # for another pool.
    projected_end_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    cause: Mapped["Cause"] = relationship(back_populates="missions")
    winning_tiv: Mapped[Optional["Initiative"]] = relationship(
        foreign_keys="Mission.winning_tiv_id"
    )
    winning_org: Mapped[Optional["Organization"]] = relationship(
        foreign_keys="Mission.winning_org_id"
    )
    tivs: Mapped[list["Initiative"]] = relationship(
        back_populates="mission", foreign_keys="Initiative.mission_id"
    )
    candidacies: Mapped[list["MissionCandidacy"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )
    votes_p1: Mapped[list["VoteP1"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )
    votes_p2: Mapped[list["VoteP2"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )
    pool: Mapped[Optional["Pool"]] = relationship(
        back_populates="mission", uselist=False, cascade="all, delete-orphan"
    )
    credit_coins: Mapped[list["CreditCoin"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )
    posts: Mapped[list["Post"]] = relationship(
        back_populates="mission", foreign_keys="Post.mission_id"
    )
    claims: Mapped[list["OrgClaim"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )
    steps: Mapped[list["MissionStep"]] = relationship(
        back_populates="mission", cascade="all, delete-orphan"
    )


# ===========================================================================
# Initiative ("tiv") — a candidate idea. Proposed under a cause; once it enters
# a cycle it points at that Mission. Winner named by Mission.winning_tiv_id.
# ===========================================================================
class Initiative(Base):
    __tablename__ = "initiatives"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    emoji: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    cause_id: Mapped[str] = mapped_column(ForeignKey("causes.id"), nullable=False)
    mission_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("missions.id"), nullable=True  # NULL while merely 'suggested'
    )

    proposer_ben_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    proposer_org_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("organizations.id"), nullable=True
    )
    proposed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # aggregated average of this tiv's VoteP1 valence (recomputed in crud).
    rating_avg: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    rating_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    logo_url: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    status: Mapped[str] = mapped_column(String, default="suggested", nullable=False)
    approved: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # staff-set

    cause: Mapped["Cause"] = relationship()
    mission: Mapped[Optional["Mission"]] = relationship(
        back_populates="tivs", foreign_keys="Initiative.mission_id"
    )
    proposer_ben: Mapped[Optional["BenefactorAccount"]] = relationship(
        foreign_keys="Initiative.proposer_ben_id"
    )
    proposer_org: Mapped[Optional["Organization"]] = relationship(
        foreign_keys="Initiative.proposer_org_id"
    )
    votes_p1: Mapped[list["VoteP1"]] = relationship(back_populates="tiv")


# ===========================================================================
# InitiativeSlug — every address an initiative has ever had (D13, 2026-09-24).
# "Old titles of the initiative should also link to the new title." One row
# per slug; exactly one per initiative is `is_current`. A rename adds a row and
# demotes the old one, so /m/<old-slug> still resolves and forwards.
# ===========================================================================
class InitiativeSlug(Base):
    __tablename__ = "initiative_slugs"

    slug: Mapped[str] = mapped_column(String, primary_key=True)
    tiv_id: Mapped[str] = mapped_column(ForeignKey("initiatives.id"), nullable=False, index=True)
    is_current: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ===========================================================================
# ContactMessage — the footer's "Contact us" (2026-09-25). Every message is
# stored; if mail is configured (SMTP_HOST …) it is also emailed to
# CONTACT_TO (jax@earthbux.net). `emailed` records whether that happened, so
# nothing is lost while there is no mail transport.
# ===========================================================================
class ContactMessage(Base):
    __tablename__ = "contact_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    topic: Mapped[str] = mapped_column(String, nullable=False, default="general")
    body: Mapped[str] = mapped_column(Text, nullable=False)
    page: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    ben_id: Mapped[Optional[int]] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=True)
    status: Mapped[str] = mapped_column(String, nullable=False, default="new")   # new | read | answered
    emailed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ===========================================================================
# Organization — a vetted org. Logs in via Memberships (people), not directly.
# Its causes are derived: org -> candidacies -> missions -> cause.
# ===========================================================================
class Organization(Base):
    __tablename__ = "organizations"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    website_link: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    founded_year: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    founding_member_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    joined_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    score: Mapped[float] = mapped_column(Float, default=0.0)
    logo_url: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    memberships: Mapped[list["Membership"]] = relationship(
        back_populates="org", cascade="all, delete-orphan"
    )
    candidacies: Mapped[list["MissionCandidacy"]] = relationship(back_populates="org")
    posts: Mapped[list["Post"]] = relationship(
        back_populates="org_author", foreign_keys="Post.org_author_id"
    )


# ===========================================================================
# BenefactorAccount ("ben") — the personal login. Three user categories via
# `role`. Org access is through Membership; employees are bens with elevated role.
# ===========================================================================
class BenefactorAccount(Base):
    __tablename__ = "benefactor_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    email: Mapped[str] = mapped_column(String, unique=True, nullable=False, index=True)
    handle: Mapped[str] = mapped_column(String, unique=True, nullable=False, index=True)
    pass_hash: Mapped[str] = mapped_column(String, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # 'benefactor' (default) | 'employee' | 'admin'. Only employee/admin may
    # approve tivs & orgs, post editorial/headline, and use the Query console.
    role: Mapped[str] = mapped_column(String, default="benefactor", nullable=False)

    vvv: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # set after first p2 vote
    # 2026-09-16 (build-seq §2) — the BOT SIGNATURE. True for accounts driven by
    # scripts/bots/ebx_bots.py. Set at signup only when the request carries the
    # server's EBX_BOT_KEY (so nobody can mark themselves), or by staff through
    # POST /admin/accounts/{id}/test. Bots vote and post like anyone else; this
    # is how they are found, excluded from public member counts, and removed
    # before real money is used.
    is_test: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False,
                                          server_default="0")
    watched_tiv_ids: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON list

    # ── the wallet (2026-08-19, token_model.py) ────────────────────────────
    # Money is held in CENTITOKENS: 1 token = 100 ct = 10c, so 1 ct = 0.1c.
    # Integers end to end — the float EBX in votes_p1 is why the live db holds
    # 123.7142858 and why a 0.5-EBX skim books as 0 in the ledger.
    #   free_ct  the UNCOMMITTED balance. "Your uncommitted balance is topped up
    #            to 10 every week": the grant is 10 - free_ct, floored at 0. A
    #            top-up, not a reward and not a forfeiture.
    #   cash_ct  refunds land here and NEVER back in tokens, which is what keeps
    #            the grant arithmetic honest — nobody is billed a grant for money
    #            handed back to them.
    #            2026-08-20b: free_ct is UNALLOCATED, and unallocated contains
    #            exactly two things — granted and purchased. Committed ct never
    #            comes back to it, so the granted part is `free_ct -
    #            purchased_ct` and there is no third category to track.
    free_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cash_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # Cycle week index of the last top-up. Grants are idempotent per week: a
    # page load must never be able to pay one twice.
    last_grant_week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    #   purchased_ct  the part of free that was BOUGHT, not granted (2026-08-20).
    #            "Purchased tokens are the same as granted tokens except they do
    #            not have a deadline to commit" — and they carry no two-door
    #            restriction either, so they behave like returned balance. Held
    #            apart only so the unallocated strip can say which uncommitted
    #            tokens are on a clock.
    #   grant_commit_by_week  the week by which fresh_ct must be committed. A
    #            missed deadline is not a forfeiture: it takes next week's date
    #            (token_model.roll_commit_by), because the cap on hoarding is the
    #            top-up formula, not a punishment.
    #   purchased_ct  the part of free that was BOUGHT rather than granted.
    #            Authoritative; the granted part is derived from it. Purchased ct
    #            carries no deadline and may enter any race, granted ct carries a
    #            date and this week's two doors — that difference is the only
    #            reason the two are counted apart.
    purchased_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    grant_commit_by_week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    #   grant_cause_id  DROPPED 2026-09-16 (migration e1a7c3b95d20). A grant
    #            carries its WEEK (`last_grant_week`), never a cause: "the active
    #            week's cause is different between the 2 elections."

    credit_coins: Mapped[list["CreditCoin"]] = relationship(
        back_populates="owner", cascade="all, delete-orphan"
    )
    memberships: Mapped[list["Membership"]] = relationship(
        back_populates="ben", cascade="all, delete-orphan"
    )
    votes_p1: Mapped[list["VoteP1"]] = relationship(
        back_populates="ben", cascade="all, delete-orphan"
    )
    votes_p2: Mapped[list["VoteP2"]] = relationship(
        back_populates="ben", cascade="all, delete-orphan"
    )
    posts: Mapped[list["Post"]] = relationship(
        back_populates="ben_author", foreign_keys="Post.ben_author_id"
    )

    @property
    def is_staff(self) -> bool:
        return self.role in ("employee", "admin")
# ===========================================================================
# Membership — person <-> org link with a role (association object).
# ===========================================================================
class Membership(Base):
    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("ben_id", "org_id", name="uq_member_org"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"))
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"))
    role: Mapped[str] = mapped_column(String, default="community")  # community|rep|executive|beneficiary
    joined_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ben: Mapped["BenefactorAccount"] = relationship(back_populates="memberships")
    org: Mapped["Organization"] = relationship(back_populates="memberships")
# ===========================================================================
# MissionCandidacy — an org's BID to run a specific mission. Grants build access
# on approval; the winner sets Mission.winning_org_id. (Replaces OrgRegistration.)
# ===========================================================================
class MissionCandidacy(Base):
    __tablename__ = "mission_candidacies"
    __table_args__ = (
        UniqueConstraint("mission_id", "org_id", name="uq_candidacy_mission_org"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    mission_statement: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String, default="pending", nullable=False)  # pending|approved|withdrawn|won|lost
    submitted_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    approved_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True  # the employee who approved
    )
    p2_vote_tally: Mapped[int] = mapped_column(Integer, default=0)  # denormalised
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    mission: Mapped["Mission"] = relationship(back_populates="candidacies")
    org: Mapped["Organization"] = relationship(back_populates="candidacies")
# ===========================================================================
# OrgClaim — THE gate. A real representative's click-through acceptance of the
# legal agreement for one (mission, org). Recording a claim grants the org
# authority over the mission's budget/sequence and bumps the mission's
# guaranteed-to-pool rate. kind: 'claim' (nominated org claims) | 'register'
# (self-registration path). Attestation text version + timestamp + ben are the
# litigation basis.
# ===========================================================================
class OrgClaim(Base):
    __tablename__ = "org_claims"
    __table_args__ = (
        UniqueConstraint("mission_id", "org_id", name="uq_claim_mission_org"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"), nullable=False)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False)
    kind: Mapped[str] = mapped_column(String, default="claim", nullable=False)  # claim | register
    attestation_version: Mapped[str] = mapped_column(String, nullable=False)
    member_name: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    member_position: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    accepted_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    mission: Mapped["Mission"] = relationship(back_populates="claims")
    org: Mapped["Organization"] = relationship()
    ben: Mapped["BenefactorAccount"] = relationship()
# ===========================================================================
# MissionStep — one STEP of the release phase (§1d). Each step carries a
# guaranteed and a potential pool (no maximums), finalized by the end of the
# budgeting phase. Resolving a step is a RESOLUTION: it grants the evaluation
# point and moves the mission's credit-coin value. Also powers the admin gantt.
# ===========================================================================
class MissionStep(Base):
    __tablename__ = "mission_steps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False)
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    order_num: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    guaranteed_ebx: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    potential_ebx: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # open-ended
    starts_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    due_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String, default="planned", nullable=False)  # planned|active|resolved
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    mission: Mapped["Mission"] = relationship(back_populates="steps")
# ===========================================================================
# VoteP1 — TIV election. Split-vote economy: a ben can spread share across
# several tivs (>=0.1 each, sum <=1.0); one row per (ben, tiv). Committed EBX
# lives here. `valence` is the hook for the voting redesign:
#   helpful = vote FOR  |  neutral = abstain/soft  |  harmful = vote AGAINST.
# Weighting & negative-detraction math is computed in crud, not stored here.
# ===========================================================================
class VoteP1(Base):
    __tablename__ = "votes_p1"
    __table_args__ = (
        # 2026-09-17: per MISSION. A losing initiative is re-listed in its cause's
        # next election, and a backer must be able to vote for it again there.
        UniqueConstraint("ben_id", "mission_id", "tiv_id", name="uq_votep1_ben_mission_tiv"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"))
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"))
    tiv_id: Mapped[str] = mapped_column(ForeignKey("initiatives.id"))

    share: Mapped[float] = mapped_column(Float, default=1.0, nullable=False)  # >=0.1
    ebx_committed: Mapped[float] = mapped_column(Float, default=0, nullable=False)  # holdings x share (continuous, no rounding)
    # ── the amount, apart from the vote (2026-08-27c) ──────────────────────
    # "The vote commit is the total amount committed to that election, and the
    # weight is the percentage given to each tiv within it." `share` is the
    # vote and it needs no tokens to stand; `stake_ct` is this row's slice of
    # the election-level commit — `commit x share`, largest-remainder, so a
    # mission's rows sum to the commit exactly. `ebx_committed` is the float it
    # replaces, kept in step for rows and reports written against it.
    stake_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    valence: Mapped[str] = mapped_column(String, default="helpful", nullable=False)  # helpful|neutral|harmful
    committed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ben: Mapped["BenefactorAccount"] = relationship(back_populates="votes_p1")
    mission: Mapped["Mission"] = relationship(back_populates="votes_p1")
    tiv: Mapped["Initiative"] = relationship(back_populates="votes_p1")
# ===========================================================================
# VoteP2 — ORG election. "1 vote, 1 org; extra votes bought at rising prices."
# One row per (ben, mission). `valence` harmful = BLOCK the org (same cost as
# support, per the redesign).
# ===========================================================================
class VoteP2(Base):
    __tablename__ = "votes_p2"
    __table_args__ = (
        UniqueConstraint("ben_id", "mission_id", name="uq_votep2_ben_mission"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"))
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"))
    # NULLABLE since 2026-08-19: when an initiative election closes, every
    # backer's non-claimed remainder moves into the WINNING initiative's OE
    # automatically and arrives with no philanthropy named. Such a stake funds
    # the mission, carries no vote weight, and defaults to the winner of the
    # race it landed in unless the benefactor picks one.
    org_id: Mapped[Optional[str]] = mapped_column(ForeignKey("organizations.id"), nullable=True)

    votes: Mapped[int] = mapped_column(Integer, default=1, nullable=False)  # 1 + bought
    ebx_spent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # ── the explicit stake (2026-08-19, token_model.py) ────────────────────
    # Phase-2 weight used to be DERIVED — p2_ebx_by_ben summed the benefactor's
    # surviving VoteP1 rows for this mission. That holds only while phase-2
    # money can arrive by one route and never move again. The OE table is now
    # eight rows with a slider each and a stake can move between them, so the
    # stake is stored. Authoritative when > 0; the derived figure is the
    # fallback for rows written before this column existed.
    stake_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # Where these ct entered the system. The initiative election puts them in
    # ONE organization election — the winning initiative's — and that race is
    # this stake's default: "if they don't [vote for a philanthropy elsewhere],
    # the token defaults to the OE from the tiv it was created within."
    origin_mission_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    born_week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    # 2026-08-20 — the conversion budget that replaced the 15-week fuse. Moving
    # a stake to a race other than its origin costs one of three, and a
    # conversion is only SPENT when a philanthropy is actually voted for there;
    # parking ct on another row and never voting is not a conversion, it is a
    # stake that will fall back to its origin.
    conversions: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # ── the week change, and the two states after `committed` (2026-08-27c) ──
    # committed_week  the week this allocation was made. Inside its own week it
    #     is a DRAFT — move it as often as you like, at no cost; at the roll it
    #     hardens. This one column is the whole of the rule that replaced both
    #     the conversion budget (above, now unread) and one-way commitment.
    # minted_ct  the part of this stake that has hardened into EBX: mission-tied,
    #     immovable, the benefactor's holding. Booked, not derived — a history
    #     cannot be recomputed from a balance.
    # donated_ct  the part that has crossed over to the mission and Earthbux, in
    #     tranches, deductible at the date of each. The 10% at the organization
    #     election is the first one, not a separate charge outside the flow.
    # marked_tiv_id  set when this benefactor's initiative LOST: these ct are
    #     still tokens, marked with what they backed, and may move to another
    #     organization election by voting for a philanthropy there. A row with no
    #     mark in a decided ME is early EBX — the winner's reward.
    committed_week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    minted_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    donated_ct: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    marked_tiv_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    # "Every token maintains a record of its transactions." A list of registered
    # votes these ct have supported; it survives a split and the mint, so a
    # credit coin still knows which initiative its money backed. Only COMMITTED
    # votes are recorded — second thoughts before a commit leave nothing behind.
    provenance: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    valence: Mapped[str] = mapped_column(String, default="helpful", nullable=False)  # helpful|neutral|harmful(=block)
    committed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ben: Mapped["BenefactorAccount"] = relationship(back_populates="votes_p2")
    mission: Mapped["Mission"] = relationship(back_populates="votes_p2")
    # One-directional on purpose: an org doesn't carry a back-collection of the
    # votes for/against it (kept symmetric with how bens relate to missions).
    org: Mapped["Organization"] = relationship()
# ===========================================================================
# Pool — per-mission money aggregate (DERIVED cache; recompute on commit/rollover).
# ===========================================================================
class Pool(Base):
    __tablename__ = "pools"

    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), primary_key=True)
    phase1_total_ebx: Mapped[int] = mapped_column(Integer, default=0)
    phase2_total_ebx: Mapped[int] = mapped_column(Integer, default=0)
    pool_from_winners: Mapped[int] = mapped_column(Integer, default=0)  # 20% / 100% kept
    pool_from_losers: Mapped[int] = mapped_column(Integer, default=0)   # 10% / 20% kept
    total_locked: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    mission: Mapped["Mission"] = relationship(back_populates="pool")
# ===========================================================================
# CreditCoin — the EBX token issued to a ben on a mission. Owning one = community
# membership in that mission (STRUCTURE: "credits=membership").
# ===========================================================================
class CreditCoin(Base):
    __tablename__ = "credit_coins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"))
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"))
    amount_ebx: Mapped[int] = mapped_column(Integer, nullable=False)
    value: Mapped[float] = mapped_column(Float, default=1.0)  # drifts post-mint
    issued_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    redeemed: Mapped[bool] = mapped_column(Boolean, default=False)

    owner: Mapped["BenefactorAccount"] = relationship(back_populates="credit_coins")
    mission: Mapped["Mission"] = relationship(back_populates="credit_coins")
# ===========================================================================
# Post — discussion/editorial content.
# Two-tier taxonomy (2026-07-19): `category` is the SUPERcategory, `type` the
# SUBcategory. Benefactor cats: 
# budgeting{service|supply|support} -
# mission_support{context|investigation|analysis} · 
# review{case|evaluation}.
# Org/staff cats (org_update|mission_update|testimonial|editorial|headline|
# resolution) leave `type` null. Source of truth: app/post_config.py.
# ===========================================================================
class Post(Base):
    __tablename__ = "posts"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    category: Mapped[str] = mapped_column(String, default="editorial", nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    title: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    body: Mapped[str] = mapped_column(Text, nullable=False)

    author_type: Mapped[str] = mapped_column(String, default="earthbux", nullable=False)  # ben|org|earthbux
    ben_author_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    org_author_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("organizations.id"), nullable=True
    )

    mission_id: Mapped[Optional[str]] = mapped_column(ForeignKey("missions.id"), nullable=True)
    tiv_id: Mapped[Optional[str]] = mapped_column(ForeignKey("initiatives.id"), nullable=True)
    cause_id: Mapped[Optional[str]] = mapped_column(ForeignKey("causes.id"), nullable=True)
    # Target ORG for evaluation / org-scoped posts (distinct from org_author_id).
    org_id: Mapped[Optional[str]] = mapped_column(ForeignKey("organizations.id"), nullable=True)
    # case → for|against ; evaluation → positive|negative ; else null.
    stance: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    # Threaded discussion: a comment points at its parent post (null = top-level).
    parent_id: Mapped[Optional[str]] = mapped_column(ForeignKey("posts.id"), nullable=True)
    # Attached image — a data URL or stored path.
    image_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # §2a (2026-08-08) — a BUDGETING post (service / supply / support) is a
    # suggestion the mission may actually adopt, so it is not a suggestion until
    # it is costed: one estimate for the SETUP TIME and one for the COST.
    # Required for the budgeting category, null everywhere else.
    est_setup_days: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    est_cost_usd: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    # §1 (2026-08-12) — the budgeting suggestion is a COSTED LIST, not prose.
    # One object per row, shaped by the post's type:
    #   service  {kind, job, hourly_rate, days_needed}
    #   supply   {kind, item, supplier, cost}
    #   support  {kind, item}
    # The two estimates above are derived from these when they are not given,
    # so a costed list satisfies the budgeting rule on its own. Null outside
    # the budgeting category.
    line_items: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)

    # ── Post-support layer (the first layer of the mission annulus) ──────────
    # Every post carrying an ORGANIZATION tag (case · investigation ·
    # evaluation) is run through a filter and flagged, because philanthropies
    # get a weekly digest of what was written about them and they are owed an
    # honest label on it:
    #   green  — useful.
    #   orange — CRITICAL, but helpful.
    #   red    — spam, scams, or unsupported slander. We apologise for these and
    #            tell the org we are working to keep them off the platform.
    # The filter is a stub today and rates everything green (post_config
    # .classify_flag); staff can override through POST /posts/{id}/flag.
    flag: Mapped[str] = mapped_column(String, default="green", nullable=False)
    flag_reason: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # ── P3 · Posting (2026-09-29) ─────────────────────────────────────────
    # What the post is ABOUT, stated once: cause | initiative | organization |
    # mission | post | budget | none. The FK columns above stay filled for the
    # kinds that have one, so every existing filter keeps working; `target_id`
    # is the one place a post-or-budget-item target is recorded.
    target_kind: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    target_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    # Tags: a general post's subtype ("opinion", "case" …) and entity tags
    # ("tiv:<id>", "org:<id>", "cause:<id>", "mission:<id>", "post:<id>").
    tags: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    # D21: every edit is a new version (PostVersion); this is the newest.
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Vote counts IN THE POST'S CURRENT MISSION (D21: "votes count per
    # mission"). A post pulled or rolled into a new mission starts again from
    # zero there; the votes it earned before stay in `post_votes` under their
    # own `mission_id`.
    helpful_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    neutral_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    harmful_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    ben_author: Mapped[Optional["BenefactorAccount"]] = relationship(
        back_populates="posts", foreign_keys="Post.ben_author_id"
    )
    org_author: Mapped[Optional["Organization"]] = relationship(
        back_populates="posts", foreign_keys="Post.org_author_id"
    )
    mission: Mapped[Optional["Mission"]] = relationship(
        back_populates="posts", foreign_keys="Post.mission_id"
    )
    votes: Mapped[list["PostVote"]] = relationship(
        back_populates="post", cascade="all, delete-orphan"
    )
# ===========================================================================
# PostVote — per-ben reaction. 
# budgeting{service|supply|support} - helpful | not - Not counts as neutral. No harmful option.
# mission_support{context|investigation|analysis} - helpful | neutral | harmful
# review{case|evaluation}. fair|neutral|biased - same logic as mission_support
# ===========================================================================
class PostVote(Base):
    __tablename__ = "post_votes"
    __table_args__ = (
        # P3 (D21): one vote per person per post PER MISSION — a post pulled
        # into a new mission is voted on again there. `mission_scope` is the
        # mission id, or '' for a post that belongs to no mission (a NULL would
        # let the unique index admit duplicates).
        UniqueConstraint("post_id", "ben_id", "mission_scope", name="uq_post_vote_ben_mission"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(ForeignKey("posts.id"), nullable=False)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False)
    value: Mapped[str] = mapped_column(String, nullable=False)  # helpful|neutral|harmful
    mission_scope: Mapped[str] = mapped_column(String, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    post: Mapped["Post"] = relationship(back_populates="votes")
    ben: Mapped["BenefactorAccount"] = relationship()


# ===========================================================================
# P3 · Posting (2026-09-29) — versions, missions, references, leads.
# ===========================================================================
class PostVersion(Base):
    """D21: every edit is a new version, and old versions never change. The
    version an election or an Analysis used is the one pinned in `post_missions`
    / `post_refs`; the author edits forward, never back."""
    __tablename__ = "post_versions"
    __table_args__ = (UniqueConstraint("post_id", "version", name="uq_post_version"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(ForeignKey("posts.id"), nullable=False, index=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    tags: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    line_items: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class PostMission(Base):
    """Which missions a post belongs to, and the version each one keeps.

    `via`: origin (written in it) · roll (a Background carried into its cause's
    next mission, D19) · pull (its author brought it in, D21) · cite (an
    Analysis of that mission cites it). `pinned_version` is set once the
    mission's election for that type has closed — that version stays with the
    mission for good."""
    __tablename__ = "post_missions"
    __table_args__ = (UniqueConstraint("post_id", "mission_id", name="uq_post_mission"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(ForeignKey("posts.id"), nullable=False, index=True)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False, index=True)
    via: Mapped[str] = mapped_column(String, default="origin", nullable=False)
    pinned_version: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    pinned_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class PostRef(Base):
    """A reference one post makes: to another post (at the version it cited),
    a mission, or an outside link. An Analysis's Backgrounds and Investigations
    are rows here; `auto` marks the two leading ones it cannot remove."""
    __tablename__ = "post_refs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(ForeignKey("posts.id"), nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String, nullable=False)   # post | mission | link
    ref_post_id: Mapped[Optional[str]] = mapped_column(ForeignKey("posts.id"), nullable=True, index=True)
    ref_version: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    ref_mission_id: Mapped[Optional[str]] = mapped_column(ForeignKey("missions.id"), nullable=True)
    url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    label: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    auto: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    position: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class MissionLead(Base):
    """D20: the Background and the Investigation that lead a mission — fixed
    when each election closes (the Background at T, the Investigation at T+8)
    and attached to every Analysis of that mission."""
    __tablename__ = "mission_leads"

    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), primary_key=True)
    background_id: Mapped[Optional[str]] = mapped_column(ForeignKey("posts.id"), nullable=True)
    background_version: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    background_fixed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    investigation_id: Mapped[Optional[str]] = mapped_column(ForeignKey("posts.id"), nullable=True)
    investigation_version: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    investigation_fixed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
# ===========================================================================
# Query — EMPLOYEE-ONLY saved data-access tool (the "navigate the database"
# staff permission). Tooling, not domain spine. Gated to role in (employee,admin).
# ===========================================================================
class Query(Base):
    __tablename__ = "queries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    entity: Mapped[Optional[str]] = mapped_column(String, nullable=True)  # 'missions' | 'votes_p1' ...
    filters: Mapped[Optional[str]] = mapped_column(Text, nullable=True)   # JSON
    sort: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    sql: Mapped[Optional[str]] = mapped_column(Text, nullable=True)       # optional raw read-only

    created_by_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    shared: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    last_run_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    created_by: Mapped[Optional["BenefactorAccount"]] = relationship()
# ===========================================================================
# Transaction — the single append-only EBX ledger. Replaces VoteEvent: one log
# for everything that moves EBX or changes a vote in a mission. Two kinds:
#   type='vote'     -> a vote mutation (audit). Uses action (CAST|UPDATE|REMOVE),
#                      phase, target (tiv_id/org_id), old_value/new_value.
#   type='transfer' -> EBX moving into a bucket. Uses bucket and, when paid to an
#                      org, counterparty_org_id.
# Live state still lives on VoteP1/VoteP2 (committed amounts) and Pool (derived
# cache). This table is the history + the per-bucket money breakdown, so the
# vote / mission / ben classes don't have to carry audit or split columns.
#   bucket: pool | org | earthbux | evaluation | credit | refund
# ===========================================================================
class Transaction(Base):
    __tablename__ = "transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    type: Mapped[str] = mapped_column(String, nullable=False)  # vote | transfer
    ben_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("benefactor_accounts.id"), nullable=True
    )
    mission_id: Mapped[Optional[str]] = mapped_column(ForeignKey("missions.id"), nullable=True)
    phase: Mapped[Optional[str]] = mapped_column(String, nullable=True)  # p1 | p2

    # --- type='vote' fields ---
    action: Mapped[Optional[str]] = mapped_column(String, nullable=True)  # CAST | UPDATE | REMOVE
    target: Mapped[Optional[str]] = mapped_column(String, nullable=True)  # tiv_id or org_id
    old_value: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    new_value: Mapped[Optional[str]] = mapped_column(String, nullable=True)

    # --- type='transfer' fields ---
    bucket: Mapped[Optional[str]] = mapped_column(String, nullable=True)  # pool|org|earthbux|evaluation|credit|refund
    counterparty_org_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("organizations.id"), nullable=True
    )

    amount_ebx: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # used by both kinds
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ===========================================================================
# P2b · Organization experience (2026-10-02) — D28/D29.
# OrgAccount — an ORGANIZATION login, a second account kind. Never a mode of a
# benefactor account; one person may hold both. Belongs to exactly one
# organization. It has no wallet and no ballots: its JWT subject is
# "org:<id>", which every benefactor route refuses (auth.get_current_benefactor).
# The claimer becomes the first `admin` and creates the other members' logins.
# ===========================================================================
class OrgAccount(Base):
    __tablename__ = "org_accounts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String, unique=True, nullable=False, index=True)
    handle: Mapped[str] = mapped_column(String, unique=True, nullable=False, index=True)
    pass_hash: Mapped[str] = mapped_column(String, nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    position: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    role: Mapped[str] = mapped_column(String, default="member", nullable=False)  # admin | member
    # False until staff approve the application that created it.
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_test: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, server_default="0")
    created_by_id: Mapped[Optional[int]] = mapped_column(ForeignKey("org_accounts.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    org: Mapped["Organization"] = relationship()


# OrgApplication — the claim. Answers to `org_config.APPLICATION_SECTIONS`,
# kept whole (JSON) so the form can change without a migration.
class OrgApplication(Base):
    __tablename__ = "org_applications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"), nullable=False, index=True)
    account_id: Mapped[Optional[int]] = mapped_column(ForeignKey("org_accounts.id"), nullable=True)
    answers: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    attestation_version: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, default="pending", nullable=False)  # pending|approved|rejected
    created_org: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, server_default="0")
    review_note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    reviewed_by_id: Mapped[Optional[int]] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=True)
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    org: Mapped["Organization"] = relationship()
    account: Mapped[Optional["OrgAccount"]] = relationship()


# ===========================================================================
# P4 · Event log + Inbox (2026-10-04).
#
# `events` is the ONE source for notifications, the weekly update, and later
# the admin audit trail: something happened, once, with who did it and what it
# was about. `notifications` is the per-benefactor fan-out of an event (D9:
# many notifications are inbox-only). Messages are their own thing — threads
# between two benefactors who share a mission (D10: no friendships).
# ===========================================================================
class Event(Base):
    __tablename__ = "events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    # reply · reaction · cited_update · org_nominated · tiv_elected ·
    # org_elected · weekly_update · message_report (events.KINDS)
    kind: Mapped[str] = mapped_column(String, nullable=False, index=True)
    actor_ben_id: Mapped[Optional[int]] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=True)
    actor_org_id: Mapped[Optional[str]] = mapped_column(ForeignKey("organizations.id"), nullable=True)
    post_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, index=True)
    mission_id: Mapped[Optional[str]] = mapped_column(String, nullable=True, index=True)
    tiv_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    org_id: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True, index=True)
    # A key that makes the event happen once: "reaction:<post>:<n>",
    # "tiv_elected:<mission>", "weekly:<week>". NULL = may repeat.
    dedupe: Mapped[Optional[str]] = mapped_column(String, nullable=True, unique=True)
    data: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)


class Notification(Base):
    __tablename__ = "notifications"
    __table_args__ = (UniqueConstraint("ben_id", "event_id", name="uq_notification_ben_event"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ben_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False, index=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"), nullable=False, index=True)
    # What this event means for THIS person — e.g. {"outcome": "won"}.
    detail: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    event: Mapped["Event"] = relationship()


class MessageThread(Base):
    """A conversation between two benefactors (a_id < b_id), started inside a
    mission they both belong to. One thread per pair."""
    __tablename__ = "message_threads"
    __table_args__ = (UniqueConstraint("a_id", "b_id", name="uq_thread_pair"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    a_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False, index=True)
    b_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False, index=True)
    mission_id: Mapped[Optional[str]] = mapped_column(ForeignKey("missions.id"), nullable=True)
    a_read_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    b_read_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_message_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    thread_id: Mapped[int] = mapped_column(ForeignKey("message_threads.id"), nullable=False, index=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    hidden: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, server_default="0")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class MessageReport(Base):
    """The report button — staff read these (admin), the sender is not told."""
    __tablename__ = "message_reports"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("messages.id"), nullable=False, index=True)
    reporter_id: Mapped[int] = mapped_column(ForeignKey("benefactor_accounts.id"), nullable=False)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String, default="open", nullable=False)  # open | upheld | dismissed
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
