"""Mission (spine) endpoints — v2. Includes the org CLAIM gate (Build Phase 2)."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import crud, schemas
from ..auth import get_current_benefactor
from ..config import get_settings
from ..database import get_db
from ..scheduler import maybe_run
from ._deps import get_current_staff
from ..models import BenefactorAccount

router = APIRouter(prefix="/missions", tags=["missions"])
settings = get_settings()


@router.get("", response_model=list[schemas.MissionRead])
def list_missions(
    cause_id: Optional[str] = None,
    phase: Optional[str] = None,
    db: Session = Depends(get_db),
):
    # Lazily advance any due phases (throttled) so the UI shifts on vote days.
    maybe_run(db)
    return crud.list_missions(db, cause_id=cause_id, phase=phase)


@router.get("/{mission_id}", response_model=schemas.MissionRead)
def get_mission(mission_id: str, db: Session = Depends(get_db)):
    m = crud.get_mission(db, mission_id)
    if m is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return m


@router.post("", response_model=schemas.MissionRead, status_code=201)
def create_mission(
    data: schemas.MissionCreate,
    db: Session = Depends(get_db),
    staff: BenefactorAccount = Depends(get_current_staff),
):
    if crud.get_mission(db, data.id):
        raise HTTPException(status_code=409, detail="Mission already exists")
    return crud.create_mission(db, data)


@router.get("/{mission_id}/pool", response_model=schemas.PoolRead)
def get_pool(mission_id: str, db: Session = Depends(get_db)):
    if crud.get_mission(db, mission_id) is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return crud.recompute_pool(db, mission_id)


@router.get("/{mission_id}/overview", response_model=dict)
def get_overview(mission_id: str, db: Session = Depends(get_db)):
    """build-seq P1 (2026-09-24), D3 — the mission page's overview: the
    committed and guaranteed pools (ct), member count, EBX value and spend.
    Read-only; see `wallet.mission_overview`."""
    from .. import wallet as _wallet
    m = crud.get_mission(db, mission_id)
    if m is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return _wallet.mission_overview(db, m)


@router.get("/{mission_id}/budget-range", response_model=dict)
def get_budget_range(mission_id: str, db: Session = Depends(get_db)):
    """Budgeting-phase helper: org's concrete min and (uncapped) max budget."""
    if crud.get_mission(db, mission_id) is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return crud.mission_budget_range(db, mission_id)


@router.get("/{mission_id}/post-support", response_model=dict)
def get_post_support(mission_id: str, db: Session = Depends(get_db)):
    """The mission annulus, layer 1 — the post-support layer.

    Org-tagged threads (case · investigation · evaluation) grouped by the
    organization they name, each flagged green (useful) / orange (critical but
    helpful) / red (spam, scam or unsupported slander). This is the shape of
    the weekly digest philanthropies receive about what was written about them.
    """
    if crud.get_mission(db, mission_id) is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return crud.post_support_layer(db, mission_id)


# ── The claim gate (Build Phase 2, D) ───────────────────────────────────────
@router.post("/{mission_id}/claim", response_model=schemas.OrgClaimRead, status_code=201)
def claim_mission(
    mission_id: str,
    data: schemas.OrgClaimCreate,
    db: Session = Depends(get_db),
    user: BenefactorAccount = Depends(get_current_benefactor),
):
    """Persist the click-through legal acceptance (mission.html's
    acceptOrgAgreement). Verifies/creates the rep membership, records the
    attestation, and bumps the guaranteed-to-pool rate."""
    try:
        return crud.claim_mission(
            db, mission_id, user, data,
            attestation_version=settings.attestation_version,
            claimed_rate=settings.pool_rate_claimed,
        )
    except ValueError as e:
        msg = str(e)
        raise HTTPException(status_code=404 if "not found" in msg.lower() else 409, detail=msg)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))


@router.get("/{mission_id}/claims", response_model=list[schemas.OrgClaimRead])
def mission_claims(mission_id: str, db: Session = Depends(get_db)):
    if crud.get_mission(db, mission_id) is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return crud.list_claims(db, mission_id=mission_id)


@router.get("/{mission_id}/org-state", response_model=dict)
def mission_org_state(mission_id: str, org_id: str, db: Session = Depends(get_db)):
    """The mission page's three booleans for one (mission, org):
    nominated → registered/claimed → elected, plus approval + rate detail."""
    try:
        return crud.org_state(db, mission_id, org_id, unclaimed_rate=settings.pool_rate_unclaimed)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ── Release-phase structure (§1d): steps + projected mission length ─────────
@router.get("/{mission_id}/steps", response_model=list[schemas.MissionStepRead])
def mission_steps(mission_id: str, db: Session = Depends(get_db)):
    if crud.get_mission(db, mission_id) is None:
        raise HTTPException(status_code=404, detail="Mission not found")
    return crud.list_steps(db, mission_id)


@router.post("/{mission_id}/steps", response_model=schemas.MissionStepRead, status_code=201)
def create_mission_step(
    mission_id: str,
    data: schemas.MissionStepCreate,
    db: Session = Depends(get_db),
    user: BenefactorAccount = Depends(get_current_benefactor),
):
    """Add a step (org members of the mission's org, or staff). Pools are
    finalized by the end of the budgeting phase — locked after that."""
    try:
        return crud.create_step(db, mission_id, data, user)
    except ValueError as e:
        msg = str(e)
        raise HTTPException(status_code=404 if "not found" in msg.lower() else 409, detail=msg)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))


@router.post("/{mission_id}/steps/{step_id}/resolve", response_model=schemas.MissionStepRead)
def resolve_mission_step(
    mission_id: str,
    step_id: int,
    db: Session = Depends(get_db),
    user: BenefactorAccount = Depends(get_current_benefactor),
):
    """Resolve a step — a RESOLUTION: grants the evaluation point and moves the
    mission's credit-coin value."""
    try:
        return crud.resolve_step(db, step_id, user, value_bump=settings.resolution_value_bump)
    except ValueError as e:
        msg = str(e)
        raise HTTPException(status_code=404 if "not found" in msg.lower() else 409, detail=msg)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))


@router.put("/{mission_id}/projected-end", response_model=schemas.MissionRead)
def set_projected_end(
    mission_id: str,
    data: schemas.ProjectedEndSet,
    db: Session = Depends(get_db),
    user: BenefactorAccount = Depends(get_current_benefactor),
):
    """Set the projected MISSION LENGTH end date."""
    try:
        return crud.set_projected_end(db, mission_id, data.projected_end_at, user)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
