"""Earthbucks FastAPI application package."""
