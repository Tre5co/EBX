// profile_check — the rebuilt profile page, driven in a real browser.
//
//   node scripts/profile_check.js [http://127.0.0.1:8000]
//
// REWRITTEN 2026-10-07 for the profile overhaul (INSTRUCTIONS › BUILD SEQUENCE ›
// Profile): the arch (top 3/7 of the annulus, one mission per sector, three
// layers = ME · OE · budget day), the globe, You | Wallet beside it, a panel per
// arch mission, the activity feed — and the wallet itself: the grant as its own
// entity, Add funds, the committed split.
//
// (Old header, kept for history:) §1 (2026-08-28). What it guards is the SHAPE of the drawing in the build
// sequence, because the shape is the argument: three cards across the top
// (c wallet · b allocations · a profile), seven weekly windows around the
// globe, the feed underneath. Each window is a WEEK and carries one initiative
// election and one organization election, which is why every card has two
// cause colours — and it is why the clockwise rule matters: the top card reads
// organization-then-initiative left to right, the right column reads the same
// pair top to bottom, and the left column reads it the other way round because
// you are coming back UP that side.
const { chromium } = require('playwright');
const fs = require('fs');
function chromeExe() {
  const cands = [process.env.PW_CHROME,
    '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    '/opt/pw-browsers/chromium/chrome-linux/chrome',
    '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell'];
  for (const p of cands) { try { if (p && fs.statSync(p).isFile()) return p; } catch (e) {} }
  return undefined;
}
const BASE = process.argv[2] || 'http://127.0.0.1:8000';
const EMAIL = `pf-check-${Date.now()}@pf-check.example.com`;
let bad = 0, n = 0;
function ok(cond, what, detail) {
  n++; if (!cond) bad++;
  console.log('  ' + (cond ? 'ok  ' : 'FAIL') + '  ' + what + (detail ? '  ' + detail : ''));
}
const section = t => console.log('\n=== ' + t);

(async () => {
  const browser = await chromium.launch({ executablePath: chromeExe() });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e.message)));

  // A real account, so the page runs its signed-in path.
  const handle = 'pfchk' + (Date.now() % 100000);
  let r = await page.request.post(BASE + '/auth/signup',
    { data: { email: EMAIL, password: 'pw12345678', handle } });
  ok(r.ok(), 'a fresh benefactor account', 'HTTP ' + r.status());
  r = await page.request.post(BASE + '/auth/login',
    { form: { username: EMAIL, password: 'pw12345678' } });
  const token = (await r.json()).access_token;
  ok(!!token, 'and a session for it');

  await page.goto(BASE + '/profile.html');
  await page.evaluate(t => localStorage.setItem('ebx_auth_token', t), token);
  await page.goto(BASE + '/profile.html');
  await page.waitForSelector('#pf-arch', { timeout: 15000 });
  await page.waitForTimeout(1200);

  section('the arch — the top 3/7 of the annulus');
  ok(await page.$$eval('#pf-ring .pf-sec', e => e.length === 5), 'five sectors drawn (three visible, one waiting on each side)');
  ok(await page.$$eval('#pf-ring .pf-sec', e => e.every(g => g.querySelectorAll('path.pf-band').length === 3)),
     'every sector has three layers');
  const focal = await page.$$eval('#pf-ring .pf-sec', e => e.map(g => {
    const b = Array.from(g.querySelectorAll('path.pf-band')).map(p => +p.getAttribute('fill-opacity'));
    return b.indexOf(Math.max(...b)); }));
  ok(JSON.stringify(focal.slice(1, 4)) === '[0,1,2]', 'left = inner (ME), middle = middle (OE), right = outer (budget day)', JSON.stringify(focal));
  ok(await page.$$eval('#pf-arch textPath', e => e.length >= 15), 'the text rides the curve (textPath)');
  ok(await page.$('#pf-globe .pf-globe-sea') !== null, 'the globe sits at the circle\'s centre');
  const t0 = await page.textContent('.pf-weeknav__t');
  await page.click('[data-step="1"]'); await page.waitForTimeout(900);
  const t1 = await page.textContent('.pf-weeknav__t');
  ok(t0 !== t1, 'Next week moves the arch one week', t0 + ' → ' + t1);
  await page.click('[data-step="0"]'); await page.waitForTimeout(900);
  ok(await page.textContent('.pf-weeknav__t') === t0, '…and This week comes back');

  section('beside the globe — You | Wallet');
  ok(await page.$('#pf-you .pf-me__h') !== null, 'the profile');
  ok((await page.textContent('#pf-you')).includes('Donated'), 'the coins are headed "Donated"');
  ok(await page.$('#pf-you .pf-set') !== null, 'settings & options');
  ok(await page.$('#pf-wallet .pf-ent--grant') !== null, 'the grant is its own wallet entity');
  const wt = await page.textContent('#pf-wallet');
  ok(/Uncommitted/.test(wt) && /Committed/.test(wt) && /Prep/.test(wt), 'Committed (ME · OE · Prep) and Uncommitted');
  ok(await page.$$eval('#pf-wallet .pf-stat', e => e.length >= 6), 'the stats tiles');

  section('add funds');
  await page.click('#pf-wallet .pf-h [data-addfunds]');
  await page.waitForSelector('#ebw-bg');
  await page.click('#ebw-bg [data-c="500"]');
  await page.click('#ebw-bg [data-go]');
  await page.waitForTimeout(1800);
  const after = await page.textContent('#pf-wallet');
  ok(/Your funds\s*50 tk/.test(after.replace(/\s+/g, ' ')), '$5 lands as 50 tokens of your funds', after.replace(/\s+/g, ' ').slice(0, 160));

  section('the mission panels and the feed');
  ok(await page.$$eval('#pf-missions .pf-mp', e => e.length >= 3), 'a panel per arch mission');
  ok(await page.$('#pf2-newpost') !== null, '+ New post');

  section('phone width');
  await page.setViewportSize({ width: 390, height: 860 });
  await page.waitForTimeout(800);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  ok(overflow <= 1, 'no sideways scroll at 390px', overflow + 'px');

  ok(errors.length === 0, 'no page errors', errors.join(' | ').slice(0, 200));
  console.log('\n' + n + ' assertions · ' + (bad ? bad + ' FAILED' : 'PROFILE CLEAN'));
  await browser.close();
  process.exit(bad ? 1 : 0);
})();
